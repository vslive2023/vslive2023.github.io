﻿namespace StaticMain;

class Program
{

}