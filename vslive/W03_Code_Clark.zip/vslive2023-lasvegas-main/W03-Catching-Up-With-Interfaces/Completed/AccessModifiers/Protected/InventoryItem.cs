﻿namespace AccessModifiers.Protected;

public class InventoryItem
{
    public int Id { get; }
    public InventoryItem(int id)
    {
        Id = id;
    }
}
