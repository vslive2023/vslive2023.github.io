﻿namespace InterfaceProperties;

public class BadObject : IBadInterface
{
}
